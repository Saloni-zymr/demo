from django.contrib import admin
from django.urls import path, include
from rest_framework.authtoken.views import obtain_auth_token
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include("User.urls")),
    # path('api-token-auth/', views.obtain_auth_token),
    path('api-auth/', include('rest_framework.urls')),
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('gettoken/', obtain_auth_token)
]

#Token generate karva: path('gettoken/', obtain_auth_token)
# http POST http://127.0.0.1:8000/gettoken/ username="root" password="root" command in terminal
# HTTP/1.1 200 OK
# Allow: POST, OPTIONS
# Content-Length: 52
# Content-Type: application/json
# Cross-Origin-Opener-Policy: same-origin
# Date: Thu, 19 May 2022 11:55:06 GMT
# Referrer-Policy: same-origin
# Server: WSGIServer/0.2 CPython/3.9.12
# X-Content-Type-Options: nosniff
# X-Frame-Options: DENY
#
# {
#     "token": "b41a6ed9ae0e5506a640ddbdbfa09a1b2451a06e"
# }



