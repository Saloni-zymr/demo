from django.urls import path, include
from .views import PassengerViewSet, BookingDetailsViewSet, FlightViewSet, User1ViewSet, RegisterUser, UserLoginViewSet
from rest_framework import routers

routers = routers.DefaultRouter()
routers.register(r'user', User1ViewSet)
routers.register(r'flight', FlightViewSet)
routers.register(r'bookingdetails', BookingDetailsViewSet, basename="booking")
routers.register(r'passenger', PassengerViewSet)

urlpatterns = [
    path('', include(routers.urls)),
    path('login/', UserLoginViewSet.as_view({'get': 'list'})),
    path('register/', RegisterUser.as_view()),
]


