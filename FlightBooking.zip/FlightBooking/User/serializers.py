from rest_framework import serializers
from .models import User1, Flight, BookingDetails, Passenger
from django.contrib.auth.models import User


class User1Serializer(serializers.ModelSerializer):
    class Meta:
        model = User1
        fields = "__all__"


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["username", "password"]

    # Password hash karva

    def create(self, validated_data):
        user = User.objects.create(username=validated_data['username'])
        user.set_password(validated_data['password'])
        user.save()
        return user


class FlightSerializer(serializers.ModelSerializer):
    class Meta:
        model = Flight
        fields = "__all__"


class BookingDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = BookingDetails
        fields = "__all__"
        depth = 1


class PassengerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Passenger
        fields = "__all__"


class LoginSerializer(serializers.ModelSerializer):
    class Meta:
        model = User1
        fields = ["email", "passw"]
