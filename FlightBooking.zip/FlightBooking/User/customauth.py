from pkg_resources import _
from rest_framework.authentication import TokenAuthentication, BasicAuthentication
from rest_framework.exceptions import AuthenticationFailed
from django.contrib.auth.models import User
from rest_framework_simplejwt.authentication import JWTAuthentication

#
#
# class CustomAuthentication(JWTAuthentication):
#     def authenticate(self, request):
#         username = request.GET.get('username')
#         if username is None:
#             return None
#
#         try:
#             user = User.objects.get(username='username')
#         except User.DoesNotExist:
#             raise AuthenticationFailed('No Such User')
#         return (user, None)
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.response import Response
from .serializers import User1Serializer
from django.contrib.auth import authenticate, get_user_model
from rest_framework import exceptions, authentication


class UserLoginAuth(authentication.BaseAuthentication):
    def authenticate(self, request):
        serializer = User1Serializer(data=request.data)
        # Get the email and password
        email = request.data.get('email', None)
        password = request.data.get('passw', None)

        if not email or not password:
            raise exceptions.AuthenticationFailed(_('No credentials provided.'))

        credentials = {
            'email': email,
            'passw': password
        }

        user = authenticate(**credentials)

        if user is None:
            raise exceptions.AuthenticationFailed(_('Invalid username/password.'))

        if not user.is_active:
            raise exceptions.AuthenticationFailed(_('User inactive or deleted.'))

        return (user, None)  # authentication successful
