from requests_oauthlib.oauth1_auth import unicode

from .models import User1, Flight, BookingDetails, Passenger
from .serializers import UserSerializer, FlightSerializer, BookingDetailsSerializer, PassengerSerializer, \
    User1Serializer, LoginSerializer
from rest_framework import viewsets
from django_filters.rest_framework import DjangoFilterBackend, filters
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from rest_framework.permissions import IsAuthenticated, IsAdminUser, DjangoModelPermissions, AllowAny, \
    IsAuthenticatedOrReadOnly
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.authentication import BasicAuthentication, SessionAuthentication, TokenAuthentication
from .customauth import UserLoginAuth


class User1ViewSet(viewsets.ModelViewSet):
    queryset = User1.objects.all()
    serializer_class = User1Serializer
    # authentication_classes = [CustomAuthentication]
    # permission_classes = [IsAuthenticated]


# class UserLoginViewSet(viewsets.ModelViewSet):
#     queryset = User1.objects.all()
#     serializer_class = LoginSerializer
#     authentication_classes = [UserLoginAuth]
# # session authentication

class UserLoginViewSet(viewsets.ModelViewSet):
    authentication_classes = (SessionAuthentication, UserLoginAuth,)
    permission_classes = (IsAuthenticated,)

    def post(self, request, format=None):
        content = {
            'user': unicode(request.user),
            'auth': unicode(request.auth),  # None
        }
        return Response(content)


from rest_framework_simplejwt.tokens import RefreshToken


class RegisterUser(APIView):
    def post(self, request):
        serializer = UserSerializer(data=request.data)

        if not serializer.is_valid():
            return Response({'status': 403, 'errors': serializer.errors, 'message': 'Something went wrong'})
        serializer.save()

        user = User.objects.get(username=serializer.data['username'])
        # token_obj, _ = Token.objects.get_or_create(user=user)
        refresh = RefreshToken.for_user(user)
        return Response(
            {'status': 200,
             'payload': serializer.data,
             'refresh': str(refresh),
             'access': str(refresh.access_token), 'message': 'data is saved'})


class FlightViewSet(viewsets.ModelViewSet):
    queryset = Flight.objects.all()
    serializer_class = FlightSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['airlines', 'dep_city', 'des_city']

    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAuthenticatedOrReadOnly]


class BookingDetailsViewSet(viewsets.ModelViewSet):
    # queryset = BookingDetails.objects.all()
    serializer_class = BookingDetailsSerializer

    # filter_backends = [OrderingFilter]
    # ordering_fields = ['trip_date', 'des_city']

    def get_queryset(self):
        book = BookingDetails.objects.all()
        return book

    def create(self, request, *args, **kwargs):
        data = request.data

        user = User.objects.get(pk=data["u_id"])
        flightdetails = Flight.objects.get(pk=data["f_id"])

        new_book = BookingDetails.objects.create(
            trip_date=data["trip_date"],
            no_of_passengers=data["no_of_passengers"],
            price=flightdetails.price * len(data["passenger"]),
            u_id=user,
            f_id=flightdetails,
        )
        new_book.save()
        for passenger in data["passenger"]:
            p = Passenger.objects.create(
                name=passenger["name"],
                age=passenger["age"],
                gender=passenger["gender"],
                contact=passenger["contact"],
                u_id=user,
            )
            new_book.passenger.add(p)

        if flightdetails.avail_seats < len(data["passenger"]):
            return Response({"data": "No seats available", "status": status.HTTP_400_BAD_REQUEST})
        update_seats = flightdetails.avail_seats - data["no_of_passengers"]
        flightdetails.avail_seats = update_seats
        flightdetails.save()
        serializers = BookingDetailsSerializer(new_book)
        return Response({"data": serializers.data, "status": status.HTTP_201_CREATED})


# from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication


class PassengerViewSet(viewsets.ModelViewSet):
    # Passenger details authenticate arva mate tokan ne header ma add kariye to passenger ni details batave.
    # JwtAuthantication thi access token male tene auth ma bearer token ma paste karvathi passenger na data joi sakay
    queryset = Passenger.objects.all()
    serializer_class = PassengerSerializer
