from django.db import models


class User1(models.Model):
    name = models.CharField(max_length=50, null=False)
    email = models.EmailField(max_length=50)
    contact = models.IntegerField(default=0)
    passw = models.CharField(max_length=7, null=False)
    city = models.CharField(max_length=30)



# using this signals if user will be added Token will automatically generated
from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver
from rest_framework.authtoken.models import Token


# @receiver(post_save, sender=settings.AUTH_USER_MODEL)
# def create_auth_token(sender, instance=None, created=False, **kwargs):
#     if created:
#         Token.objects.create(user=instance)


class Flight(models.Model):
    Ticket = (
        ('B', 'Business Class'),
        ('E', 'Economic Class'),
    )
    airlines = models.CharField(max_length=30)
    dep_time = models.TimeField(max_length=30)
    dep_date = models.DateField()
    duration = models.TimeField()
    ticket_type = models.CharField(max_length=30, choices=Ticket)
    price = models.IntegerField()
    dep_city = models.CharField(max_length=30)
    des_city = models.CharField(max_length=30)
    runway_no = models.IntegerField()
    total_seats = models.IntegerField()
    avail_seats = models.IntegerField()


class Passenger(models.Model):
    Gender = (
        ('F', 'Female'),
        ('M', 'Male'),
    )
    name = models.CharField(max_length=20)
    age = models.IntegerField()
    contact = models.IntegerField()
    u_id = models.ForeignKey(User1, on_delete=models.CASCADE)
    gender = models.CharField(max_length=10)


class BookingDetails(models.Model):
    u_id = models.ForeignKey(User1, on_delete=models.CASCADE)
    f_id = models.ForeignKey(Flight, on_delete=models.CASCADE)
    trip_date = models.DateField()
    booking_date = models.DateTimeField(auto_now_add=True)
    des_city = models.CharField(max_length=30)
    passenger = models.ManyToManyField(Passenger)
    no_of_passengers = models.IntegerField(default=1)
    price = models.IntegerField(default=0)
