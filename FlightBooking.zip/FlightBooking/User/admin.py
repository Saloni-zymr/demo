from django.contrib import admin
from .models import User1, Passenger, Flight, BookingDetails
from rest_framework.authtoken.admin import TokenAdmin

TokenAdmin.raw_id_fields = ['user']
admin.site.register(User1)
admin.site.register(Flight)
admin.site.register(Passenger)
admin.site.register(BookingDetails)
